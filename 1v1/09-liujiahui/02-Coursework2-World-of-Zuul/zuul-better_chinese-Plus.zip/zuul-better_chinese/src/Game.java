/**
 *  该类是 "祖尔的世界" 应用程序的主类。
 *  "祖尔的世界" 是一个非常简单的、基于文本的冒险游戏。
 *  用户可以在一些场景中散步。这就是全部。它真的应该被扩展，以使其更有趣!
 * 
 *  要玩这个游戏，需要创建这个类的一个实例，并调用 "play" 方法。
 * 
 *  这个主类创建并初始化所有其他的类：
 *  它创建所有的房间，创建解析器并启动游戏。
 *  它还评估和执行解析器返回的命令。
 *
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class Game 
{
    private Parser parser;  // parser 中文为：解析器
    private Room currentRoom;
        
    /**
     * 创建游戏并初始化其内部地图。
     */
    public Game() 
    {
        createRooms();
        parser = new Parser();
    }

    /**
     * 创建所有的房间并将它们的出口连接在一起。
     */
    private void createRooms()
    {
        Room outside, theater, pub, lab, office;
      
        // create the rooms
        outside = new Room("大学正门外");
        theater = new Room("在一个演讲厅里");
        pub = new Room("在校园的酒吧里");
        lab = new Room("在计算机实验室");
        office = new Room("在计算机管理办公室");
        
        // initialise room exits
        outside.setExit("东边", theater);
        outside.setExit("南边", lab);
        outside.setExit("西边", pub);

        theater.setExit("西边", outside);

        pub.setExit("东边", outside);

        lab.setExit("北边", outside);
        lab.setExit("东边", office);

        office.setExit("西边", lab);

        currentRoom = outside;  // 在外面（outside）开始游戏
    }

    /**
     *  主要的游戏程序。 循环，直到游戏结束。
     */
    public void play() 
    {            
        printWelcome();

        // 进入主命令循环。
        // 在这里，我们反复读取命令并执行它们，直到游戏结束。
                
        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
        }
        System.out.println("谢谢您的游玩。 再见。");
    }

    /**
     * 打印出给玩家的开场白。
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("欢迎来到祖尔的世界!");
        System.out.println("祖尔的世界是一款新的、令人难以置信的无聊冒险游戏。");
        System.out.println("如果你需要帮助，请输入'帮助'");
        System.out.println();
        System.out.println(currentRoom.getLongDescription());
    }

    /**
     * 给出一条命令，处理（即：执行）该命令。
     * @param command 要处理的命令。
     * @return true 如果该命令结束游戏，否则 return false
     */
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;

        if(command.isUnknown()) {
            System.out.println("我不知道你啥意思...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equals("帮助")) {
            printHelp();
        }
        else if (commandWord.equals("去")) {
            goRoom(command);
        }
        else if (commandWord.equals("退出")) {
            wantToQuit = quit(command);
        }
        // else 命令不被识别。
        return wantToQuit;
    }

    // 用户命令的实现：

    /**
     * 打印出一些帮助信息。
     * 在这里，我们打印一些愚蠢的、隐秘的信息和一个包含着命令字的列表。
     */
    private void printHelp() 
    {
        System.out.println("你迷失了。你是孤独的。你徘徊着");
        System.out.println("在大学里四处奔波。");
        System.out.println();
        System.out.println("你的命令字是：");
        parser.showCommands();
    }

    /** 
     * 尝试向一个方向进入。如果有一个出口，就进入新的房间，否则就打印一个错误信息。
     */
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) {
            // 如果没有第二个字，我们就不知道该去哪里了...
            System.out.println("去哪？");
            return;
        }

        String direction = command.getSecondWord();

        // 试着离开目前的房间。
        Room nextRoom = currentRoom.getExit(direction);

        if (nextRoom == null) {
            System.out.println("没有门!");
        }
        else {
            currentRoom = nextRoom;
            System.out.println(currentRoom.getLongDescription());
        }
    }

    /** 
     * 输入了 "Quit"（"退出"）。检查命令的其余部分，看看我们是否真的退出了游戏。
     * @return true 如果这个命令退出游戏，否则 return false。
     */
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) {
            System.out.println("退出什么？");
            return false;
        }
        else {
            return true;  // 我们想退出的信号
        }
    }
}
