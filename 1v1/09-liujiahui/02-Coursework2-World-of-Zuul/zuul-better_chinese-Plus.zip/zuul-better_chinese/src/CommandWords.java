/**
 * 这个类 是 "祖尔的世界" 应用程序的一部分。
 * "祖尔的世界" 是一个非常简单的、基于文本的冒险游戏。
 * 
 * 该类持有游戏中已知的所有命令字的枚举。
 * 它用于识别输入的命令。
 *
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class CommandWords
{
    // 一个常量数组，用于保存所有有效的命令字
    private static final String[] validCommands = {
        "去", "退出", "帮助"
    };

    /**
     * Constructor 构造函数 - 初始化命令字。
     */
    public CommandWords()
    {
        // 目前无事可做...
    }

    /**
     * 检查一个特定 String 是否是一个有效的命令字。
     * @return true 如果是，false 如果不是。
     */
    public boolean isCommand(String aString)
    {
        for(int i = 0; i < validCommands.length; i++) {
            if(validCommands[i].equals(aString))
                return true;
        }
        // 如果我们到了这里，就说明在命令中没有找到这个字符串。
        return false;
    }

    /**
     * 打印所有有效的命令到 System.out
     */
    public void showAll() 
    {
        for(String command: validCommands) {
            System.out.print(command + "  ");
        }
        System.out.println();
    }
}
